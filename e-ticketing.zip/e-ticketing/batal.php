<?php

session_start();

if (isset($_GET["id"])) {
    $id_jadwal = $_GET["id"];

    if (isset($_SESSION["cart"][$id_jadwal])) {
        unset($_SESSION["cart"][$id_jadwal]);
    }
    header("Location: cart.php");
}
