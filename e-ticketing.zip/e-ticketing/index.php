<?php

$page = "Beranda";

require 'layouts/navbar.php';

?>

<?php

// Memeriksa apakah tombol pencarian telah ditekan
if (isset($_POST['cari'])) {
    // Mengambil nilai dari input form
    $from = $_POST['from'];
    $to = $_POST['to'];
    $date = $_POST['date'];

    // Query untuk mencari jadwal penerbangan sesuai dengan rute_asal, rute_tujuan, dan tanggal_pergi
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
        INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
        INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
        WHERE rute_asal LIKE '%$from%' AND rute_tujuan LIKE '%$to%' AND tanggal_pergi = '$date' 
        ORDER BY tanggal_pergi, waktu_berangkat");
} else {
    // Jika tombol pencarian tidak ditekan, tampilkan semua jadwal penerbangan
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
        INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
        INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");
}
?>

<style>
    .hero-bg {
        background-image: url('assets/images/hero-bg.jpeg');
        background-size: cover;
        background-position: center;
        padding-top: 190px;
        padding-bottom: 100px;
    }
</style>

<div class="container-fluid hero-bg">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="text-center mb-4 text-white">
                    <h2>Cari Tiket Pesawat</h2>
                    <p>Masukkan detail perjalanan Anda untuk menemukan penerbangan yang sesuai.</p>
                </div>
                <div class="card shadow">
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="from">Dari</label>
                                        <input type="text" class="form-control" id="from" name="from" placeholder="Dari" required value="<?php echo isset($_POST['from']) ? $_POST['from'] : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="to">Ke</label>
                                        <input type="text" class="form-control" id="to" name="to" placeholder="Ke" required value="<?php echo isset($_POST['to']) ? $_POST['to'] : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="date">Tanggal Pergi</label>
                                        <input type="date" class="form-control" id="date" name="date" required value="<?php echo isset($_POST['date']) ? $_POST['date'] : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>&nbsp;</label><br>
                                        <button type="submit" class="btn btn-primary btn-block" name="cari">Cari</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>

<div class="container mt-5">
    <h2 class="mb-4">Jadwal Penerbangan</h2>
    <?php if (empty($jadwalPenerbangan)) : ?>
        <div class="alert alert-warning" role="alert">
            Maaf, tidak ada jadwal penerbangan yang sesuai dengan kriteria pencarian Anda.
        </div>
    <?php else : ?>
        <div class="list-tiket-pesawat-scroll" style="overflow-x: auto;">
            <div class="list-tiket-pesawat row pl-3">
                <?php foreach ($jadwalPenerbangan as $index => $data) : ?>
                    <div class="col mb-4">
                        <a href="detail.php?id=<?= $data["id_jadwal"]; ?>" class="text-decoration-none text-dark">
                            <div class="card shadow" style="max-width: 13rem;">
                                <img src="assets/images/<?= $data["logo_maskapai"]; ?>" class="card-img-top" alt="<?= $data["nama_maskapai"]; ?>" height="150">
                                <div class="card-body">
                                    <h5 class="card-title"><?= $data["nama_maskapai"]; ?></h5>
                                    <p class="card-text"><?= $data["tanggal_pergi"]; ?></p>
                                    <p class="card-text"><?= $data["waktu_berangkat"]; ?> - <?= $data["waktu_tiba"]; ?></p>
                                    <p class="card-text"><?= $data["rute_asal"] ?> - <?= $data["rute_tujuan"]; ?></p>
                                    <p class="card-text">Rp <?= number_format($data["harga"]); ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>


<?php require 'layouts/footer.php'; ?>