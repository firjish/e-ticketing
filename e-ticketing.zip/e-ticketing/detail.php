<?php require 'layouts/navbar.php'; ?>

<?php 

$id = $_GET["id"];

$jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE id_jadwal = '$id'")[0];

?>

<style>
    .card {
        width: 400px;
        margin: 0 auto;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .card img {
        width: 100%;
        height: auto;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .card-body {
        padding: 20px;
    }
</style>

<div class="list-tiket-pesawat container mt-5">
    <h1 class="mb-4 text-center">Jadwal Penerbangan - E Ticketing</h1>
    
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <img src="assets/images/<?= $jadwalPenerbangan["logo_maskapai"]; ?>" class="card-img-top" alt="Logo Maskapai">
                <div class="card-body">
                    <h5 class="card-title text-center mb-4">Informasi Penerbangan</h5>
                    <p><strong>Nama Maskapai:</strong> <?= $jadwalPenerbangan["nama_maskapai"]; ?></p>
                    <p><strong>Rute Asal:</strong> <?= $jadwalPenerbangan["rute_asal"]; ?></p>
                    <p><strong>Rute Tujuan:</strong> <?= $jadwalPenerbangan["rute_tujuan"]; ?></p>
                    <p><strong>Tanggal Berangkat:</strong> <?= $jadwalPenerbangan["tanggal_pergi"]; ?></p>
                    <p><strong>Waktu Berangkat:</strong> <?= $jadwalPenerbangan["waktu_berangkat"]; ?></p>
                    <p><strong>Waktu Tiba:</strong> <?= $jadwalPenerbangan["waktu_tiba"]; ?></p>
                    <p><strong>Harga Tiket:</strong> Rp <?= number_format($jadwalPenerbangan["harga"]); ?></p>
                    <p><strong>Sisa Kursi:</strong> <?= $jadwalPenerbangan["kapasitas_kursi"]; ?></p>
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label for="qty" class="form-label">Jumlah Tiket:</label>
                            <input type="number" id="qty" name="qty" class="form-control" value="1" min="1">
                        </div>
                        <div class="text-center">
                            <button type="submit" name="pesan" class="btn btn-primary">Pesan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php

if(isset($_POST["pesan"])){
    if($_POST["qty"] > $jadwalPenerbangan["kapasitas_kursi"]){
        echo "
            <script type='text/javascript'>
                alert('Mohon maaf kuantitas yang kamu beli melebihi kuantitas yang tersedia');
            </script>
        ";
    }else if($_POST["qty"] <= 0){
        echo "
        <script type='text/javascript'>
            alert('Beli setidaknya 1 tiket, ya!');
            window.location = 'index.php';
        </script>
        ";
    }else{
        $qty = $_POST["qty"];
        $_SESSION["cart"][$id] = $qty;
        echo "
        <script type='text/javascript'>
            window.location = 'cart.php';
        </script>
        ";
    }
}

?>
