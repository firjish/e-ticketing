<?php

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if (isset($_POST["tambah"])) {
    if (tambah($_POST) > 0) {
        echo "
            <script type='text/javascript'>
                alert('Yay! data pengguna berhasil ditambahkan!')
                window.location = 'index.php'
            </script>
        ";
    } else {
        echo "
            <script type='text/javascript'>
                alert('Yah.. data pengguna gagal ditambahkan!')
                window.location = 'index.php'
            </script>
        ";
    }
}

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main-content mt-5">
    <h1 class="text-center fw-bold fs-2 mb-4">Tambah Pengguna</h1>
    <form action="" method="POST" class="border border-2 rounded p-4">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control">
        </div>
        <div class="mb-3">
            <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control">
        </div>
        <div class="mb-3">
            <label for="roles" class="form-label">Roles</label>
            <select name="roles" id="roles" class="form-select">
                <option value="Petugas">Petugas</option>
                <option value="Penumpang">Penumpang</option>
            </select>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
    </form>
</div>