<?php

$page = "Data Jadwal Penerbangan";

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if ($_SESSION["roles"] !== "Admin") {
    echo "
    <script type='text/javascript'>
        alert('Maaf, Anda tidak memiliki izin untuk mengakses halaman ini.');
        window.location = '../../index.php';
    </script>
    ";
    exit();
}

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main-content mt-5">
    <h1 class="text-center fw-bold fs-2 mb-3">Data Jadwal Penerbangan</h1>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Jadwal</a>
    <div class="table-responsive">
        <table class="table table-striped table-bordered border border-2">
            <thead>
                <tr>
                    <th scope="col" class="text-center align-middle">No</th>
                    <th scope="col" class="text-center align-middle">Nama Maskapai</th>
                    <th scope="col" class="text-center align-middle">Kapasitas</th>
                    <th scope="col" class="text-center align-middle">Rute Asal</th>
                    <th scope="col" class="text-center align-middle">Rute Tujuan</th>
                    <th scope="col" class="text-center align-middle">Tanggal Pergi</th>
                    <th scope="col" class="text-center align-middle">Waktu Berangkat</th>
                    <th scope="col" class="text-center align-middle">Waktu Tiba</th>
                    <th scope="col" class="text-center align-middle">Harga</th>
                    <th scope="col" class="text-center align-middle">Kapasitas Kursi</th>
                    <th scope="col" class="text-center align-middle">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($jadwal as $data) : ?>
                    <tr>
                        <td class="text-center align-middle"><?= $no; ?></td>
                        <td class="text-center align-middle"><?= $data["nama_maskapai"]; ?></td>
                        <td class="text-center align-middle"><?= $data["kapasitas"]; ?></td>
                        <td class="text-center align-middle"><?= $data["rute_asal"]; ?></td>
                        <td class="text-center align-middle"><?= $data["rute_tujuan"]; ?></td>
                        <td class="text-center align-middle"><?= $data["tanggal_pergi"]; ?></td>
                        <td class="text-center align-middle"><?= $data["waktu_berangkat"]; ?></td>
                        <td class="text-center align-middle"><?= $data["waktu_tiba"]; ?></td>
                        <td class="text-center align-middle">Rp <?= number_format($data["harga"]); ?></td>
                        <td class="text-center align-middle"><?= $data["kapasitas_kursi"]; ?></td>
                        <td class="text-center align-middle">
                            <div class="d-grid gap-2">
                                <a href="edit.php?id=<?= $data["id_jadwal"]; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus.php?id=<?= $data["id_jadwal"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-danger btn-sm">Hapus</a>
                            </div>
                        </td>
                    </tr>
                    <?php $no++; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>