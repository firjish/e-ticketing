<?php

$page = "Dashboard";
session_start();

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}

if ($_SESSION["roles"] !== "Admin") {
    echo "
    <script type='text/javascript'>
        alert('Maaf, Anda tidak memiliki izin untuk mengakses halaman ini.');
        window.location = '../../index.php';
    </script>
    ";
    exit();
}

?>

<?php require '../layouts/sidebar_admin.php'; ?>

<div class="main-content">
    <h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
</div>