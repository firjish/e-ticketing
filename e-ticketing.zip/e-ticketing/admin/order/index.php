<?php
require 'functions.php';
$page = "Data Pemesanan Tiket";
session_start();

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}

if ($_SESSION["roles"] !== "Admin") {
    echo "
    <script type='text/javascript'>
        alert('Maaf, Anda tidak memiliki izin untuk mengakses halaman ini.');
        window.location = '../../index.php';
    </script>
    ";
    exit();
}

$orderTiket = query("SELECT * FROM order_tiket")

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main-content mt-5">
    <h1 class="text-center fw-bold fs-2 mb-4">Data Pemesanan Tiket</h1>
    <div class="table-responsive">
        <table class="table table-striped table-bordered border border-2">
            <thead>
                <tr>
                    <th scope="col" class="text-center align-middle">Nomor Order</th>
                    <th scope="col" class="text-center align-middle">Struk</th>
                    <th scope="col" class="text-center align-middle">Status</th>
                    <th scope="col" class="text-center align-middle">Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderTiket as $data) : ?>
                    <tr>
                        <td class="text-center align-middle"><?= $data["id_order"]; ?></td>
                        <td class="text-center align-middle"><?= $data["struk"]; ?></td>
                        <td class="text-center align-middle">
                            <?php
                            if ($data["status"] == "proses") {
                            ?>
                                <a href="update_status.php?id=<?= $data["id_order"]; ?>" class="text-primary" style="text-decoration: none;">Proses</a>
                            <?php
                            } else if ($data["status"] == "berhasil") {
                            ?>
                                <a href="" class="text-success" style="text-decoration: none;">Berhasil</a>
                            <?php
                            } else if ($data["status"] == "gagal") {
                            ?>
                                <a href="" class="text-danger" style="text-decoration: none;">Gagal</a>
                            <?php
                            }
                            ?>
                        </td>
                        <td class="text-center align-middle">
                            <?php if ($data["status"] == "proses") : ?>
                                <a href="verif.php?id=<?= $data["id_order"]; ?>" class="btn btn-success btn-sm">Verifikasi</a>
                                <a href="reject.php?id=<?= $data["id_order"]; ?>" class="btn btn-danger btn-sm">Reject</a>
                            <?php elseif ($data["status"] == "berhasil" || $data["status"] == "gagal") : ?>
                                <a href="hapus.php?id=<?= $data["id_order"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="text-secondary" style="text-decoration: none;">Hapus</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>