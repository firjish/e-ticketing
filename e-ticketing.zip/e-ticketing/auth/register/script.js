$(document).ready(function () {
    $("#login-link").click(function (event) {
        event.preventDefault();

        $(".register-container").fadeOut(500, function () {
            window.location.href = "../login/index.php";
        });
    });
});