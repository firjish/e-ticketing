<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/e-ticketing/assets/libraries/bootstrap/css/bootstrap.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <title>Login Form</title>

</head>

<body>
    <div class="container">
        <div class="login-container">
            <div class="logo text-center">
                <span>E - Ticketing</span>
            </div>
            <h2 class="text-secondary fs-5">Login your account</h2>
            <form action="process.php" method="POST" id="login-form">
                <div class="form-group">
                    <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                </div>
                <button type="submit" class="btn btn-login">Login</button>
            </form>
            <div class="register-link">
                <p>Don't have an account? <a href="../register/index.php" id="register-link" onclick="goToRegisterPage">Create account</a></p>
            </div>
        </div>
    </div>

    <script src="/e-ticketing/assets/libraries/jquery/dist/jquery.min.js"></script>

    <script src="script.js"></script>
</body>

</html>