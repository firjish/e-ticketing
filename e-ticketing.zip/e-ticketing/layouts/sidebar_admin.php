<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="/e-ticketing/assets/sweet-alert/css/bootstrap.min.css">
    <link rel="stylesheet" href="/e-ticketing/assets/sweet-alert/css/sweetalert.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/e-ticketing/assets/libraries/bootstrap/css/bootstrap.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="/e-ticketing/assets/style/sidebar.css">

    <title>Sidebar Admin</title>
</head>

<body>

    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="fw-bold">E - Ticketing</div>
        </div>
        <ul class="nav flex-column mb-auto">
            <li class="nav-item">
                <a href="/e-ticketing/admin/index.php" class="nav-link <?php if ($page == "Dashboard") echo "active" ?>">Dashboard</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/pengguna/" class="nav-link <?php if ($page == "Data Pengguna") echo "active" ?>">Data Pengguna</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/maskapai/" class="nav-link <?php if ($page == "Data Maskapai") echo "active" ?>">Data Maskapai</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/kota/" class="nav-link <?php if ($page == "Data Kota") echo "active" ?>">Data Kota</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/rute/" class="nav-link <?php if ($page == "Data Rute") echo "active" ?>">Data Rute</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/jadwal/" class="nav-link <?php if ($page == "Data Jadwal Penerbangan") echo "active" ?>">Data Jadwal Penerbangan</a>
            </li>
            <li class="nav-item">
                <a href="/e-ticketing/admin/order/" class="nav-link <?php if ($page == "Data Pemesanan Tiket") echo "active" ?>">Data Pemesanan Tiket</a>
            </li>
        </ul>
        <div>
            <a href="/e-ticketing/logout.php" class="nav-link" onClick="return confirm('Apakah anda yakin ingin logout?')">Logout</a>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="/e-ticketing/assets/libraries/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>

    <script src="/e-ticketing/assets/sweet-alert/js/sweetalert.min.js"></script>
    <script src="/e-ticketing/assets/sweet-alert/js/jquery-2.1.4.min.js"></script>
</body>

</html>