<?php require 'functions.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/style/navbar.css">

    <title>E-Ticketing</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">E-Ticketing</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link <?php if ($page == "Beranda") echo "active" ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a href="jadwal.php" class="nav-link <?php if ($page == "Jadwal Penerbangan") echo "active" ?>">Jadwal Penerbangan</a>
                    </li>
                    <li class="nav-item">
                        <a href="cart.php" class="nav-link <?php if ($page == "Pemesanan Tiket") echo "active" ?>">Pemesanan Tiket</a>
                    </li>
                    <li class="nav-item">
                        <a href="history.php" class="nav-link <?php if ($page == "Riwayat Pemesanan") echo "active" ?>">Riwayat Pemesanan</a>
                    </li>
                </ul>
            </div>
            <div class="authentication ms-auto">
                <?php if (isset($_SESSION["username"])) : ?>
                    <span class="navbar-text me-3"><?= $_SESSION["nama_lengkap"]; ?></span>
                    <a class="btn btn-outline-danger" href="logout.php">Logout</a>
                <?php else : ?>
                    <a class="btn btn-outline-primary me-2" href="auth/login/">Login</a>
                    <a class="btn btn-primary" href="auth/register/">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</body>

</html>