<?php

$page = "Pemesanan Tiket";

require 'layouts/navbar.php';

?>

<?php

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = 'auth/login/index.php';
    </script>
    ";
}

?>

<div class="container mt-5">
    <h2 class="mb-4">List Pemesanan Tiket</h2>
    <div class="list-tiket-pesawat">
        <?php if (empty($_SESSION["cart"])) : ?>
            <h2>Kosong</h2>
        <?php else : ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Maskapai</th>
                            <th>Rute</th>
                            <th>Tanggal Berangkat</th>
                            <th>Waktu Keberangkatan</th>
                            <th>Harga</th>
                            <th>Kuantitas</th>
                            <th>Total Harga</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $grandTotal = 0; ?>
                        <?php foreach ($_SESSION["cart"] as $id_jadwal => $kuantitas) : ?>
                            <?php
                            $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
                            INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
                            INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
                            WHERE id_jadwal = '$id_jadwal'")[0];

                            $totalHarga = $jadwalPenerbangan["harga"] * $kuantitas;
                            $grandTotal += $totalHarga;
                            ?>

                            <tr>
                                <td><?= $no; ?></td>
                                <td><?= $jadwalPenerbangan["nama_maskapai"]; ?></td>
                                <td><?= $jadwalPenerbangan["rute_asal"]; ?> - <?= $jadwalPenerbangan["rute_tujuan"]; ?></td>
                                <td><?= $jadwalPenerbangan["tanggal_pergi"]; ?></td>
                                <td><?= $jadwalPenerbangan["waktu_berangkat"]; ?> - <?= $jadwalPenerbangan["waktu_tiba"]; ?></td>
                                <td>Rp <?= number_format($jadwalPenerbangan["harga"]); ?></td>
                                <td><?= $kuantitas; ?></td>
                                <td>Rp <?= number_format($totalHarga); ?></td>
                                <td>
                                    <a href="batal.php?id=<?= $id_jadwal ?>" class="btn btn-danger">Batal</a>
                                </td>
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>

                        <tr>
                            <td colspan="8">Grand Total</td>
                            <td>Rp <?= number_format($grandTotal) ?></td>
                        </tr>
                        <tr>
                            <td colspan="9">
                                <a href="checkout.php" class="btn btn-primary">Checkout</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>